<?php

use Tests\TestCase;

class MlModelTest extends TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */
    public function test_item()
    {
        $user = new \App\Models\User();
        $user->id = 88472448;
        $result = false;  # Change to false to make the test fail
        try {
            // $result = true;
            $user->update(['name' => 'Md. Abdur Rahman Shibly']);
        } catch (Exception $e) {

        }
        $this->assertTrue($result);
    }
}
