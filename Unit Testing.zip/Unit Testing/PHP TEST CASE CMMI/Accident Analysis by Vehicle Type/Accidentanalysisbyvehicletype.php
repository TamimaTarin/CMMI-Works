<?php

use Tests\TestCase;

class AccidentanalysisbyvehicletypeTest extends TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */
    public function test_item()
    {
        $user = new \App\Models\User();
        $user->id = 82458660;
        $result = false;  # Change to false to make the test fail
        try {
            // $result = true;
            $user->update(['name' => 'Md. Abdur Rahman Shibly']);
        } catch (Exception $e) {

        }
        $this->assertTrue($result);
    }
}
