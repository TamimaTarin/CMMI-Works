<?php

use Tests\TestCase;

class LossratioanalysisTest extends TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */
    public function test_item()
    {
        $user = new \App\Models\User();
        $user->id = 12169486;
        $result = false;  # Change to false to make the test fail
        try {
            // $result = true;
            $user->update(['name' => 'Aftab Ibn Halim']);
        } catch (Exception $e) {

        }
        $this->assertTrue($result);
    }
}
