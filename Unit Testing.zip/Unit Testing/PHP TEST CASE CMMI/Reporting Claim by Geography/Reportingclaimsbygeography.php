<?php

use Tests\TestCase;

class ReportingclaimsbygeographyTest extends TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */
    public function test_item()
    {
        $user = new \App\Models\User();
        $user->id = 99513558;
        $result = false;  # Change to false to make the test fail
        try {
            // $result = true;
            $user->update(['name' => 'Zahin Mohammad Hossain']);
        } catch (Exception $e) {

        }
        $this->assertTrue($result);
    }
}
